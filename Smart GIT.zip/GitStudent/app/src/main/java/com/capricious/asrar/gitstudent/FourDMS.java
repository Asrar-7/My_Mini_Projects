package com.capricious.asrar.gitstudent;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class FourDMS extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_four_dms);
    }
}
